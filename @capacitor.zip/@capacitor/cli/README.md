# Capacitor CLI

The Capacitor command-line interface should be installed locally and executed through `npm` scripts.

```
npm install @capacitor/cli --save-dev
```

## Using Capacitor CLI

Consult the Getting Started guide for information on using the CLI and Capacitor scripts.

### License

* [MIT](https://github.com/ionic-team/capacitor/blob/HEAD/LICENSE)
