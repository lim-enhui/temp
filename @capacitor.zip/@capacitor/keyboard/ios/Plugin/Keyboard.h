#import <UIKit/UIKit.h>
#import <Capacitor/CAPPlugin.h>
#import <Capacitor/CAPBridgedPlugin.h>


@class CAPPluginCall;

@interface KeyboardPlugin : CAPPlugin <CAPBridgedPlugin>

@end

