import type { CapacitorGlobal } from '../definitions';
import type { WebPlugin } from '../web-plugin';
export declare const legacyRegisterWebPlugin: (cap: CapacitorGlobal, webPlugin: WebPlugin) => void;
